#include <iostream>
#include <chrono>
#include <ctime>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>
#include <cmath>
#include "../vector.h"



using namespace std;

//Constantes globales

const int N=3;
const double g=980;

//Dimensiones de la caja
const double Lx=0, Ly=0; 

//Constantes del algoritmo de integración
const double xi=0.1786178958448091;
const double lambda=-0.2123418310626054;
const double chi=-0.06626458266981849;
const double Um2lambdau2=(1-2*lambda)/2;
const double Um2chiplusxi=1-2*(chi+xi);

//Declaración de las clases
class Cuerpo;
class Colisionador;

//---------- Clase Cuerpo --------------
class Cuerpo{
private:
	double Theta, Omega,Tau;  double m,R, I, L, x0;
public:
  void Inicie(double Theta0,double Omega0,double m0, double R0, double L0, double x00);
  void BorreTorque(void){Tau=0;};
  void SumeTorque(double Tau0){Tau+=Tau0;};
  void Mueva_Theta(double dt,double coeficiente);
  void Mueva_Omega(double dt,double coeficiente);
  void Dibujese(void);
	double GetX(void){return x0 +L*sin(Theta);};
	double GetY(void){return -L*cos(Theta);};
	double GetTheta(void){return Theta;};
  double GetTau(void){return Tau;}; //Inline
  friend class Colisionador;
};
void Cuerpo::Inicie(double Theta0,double Omega0,double m0, double R0, double L0, double x00){
  Theta = Theta0; Omega = Omega0; m=m0; R= R0; L= L0; I =m*L*L; x0 = x00;
}
void Cuerpo::Mueva_Theta(double dt,double coeficiente){
  Theta += Omega*( coeficiente*dt);
}
void Cuerpo::Mueva_Omega(double dt,double coeficiente){
  Omega += Tau*( coeficiente*dt/I);
}
void Cuerpo::Dibujese(void){
  cout<<" , "<<GetX()<<"+"<<R<<"*cos(t),"<<GetY()<<"+"<<R<<"*sin(t)";
	 cout<<" , "<<x0<<"+"<<L/7<<"*t*sin("<<Theta<<"),-"<<L/7<<"*t*cos("<<Theta<<")";
}
//---------- Clase Colisionador --------------
class Colisionador{
private:
public:
  void CalculeTodosLosTorques(Cuerpo * Pendulo, double K);
  void CalculeTorqueEntre(Cuerpo & Pendulo1,Cuerpo & Pendulo2, double K);    
};
void Colisionador::CalculeTodosLosTorques(Cuerpo * Pendulo, double K){
  int i,j;
  //Borrar todas las fuerzas
  for(i=0;i<N;i++)
    Pendulo[i].BorreTorque();
   //Adicionar fuerzas individuales (que no son de interaccion)
   for(i=0;i<N;i++)
    Pendulo[i].SumeTorque(-Pendulo[i].L*Pendulo[i].m*g*sin(Pendulo[i].Theta));
    // for(j=i+1;j<N;j++)
    //   CalculeTorqueEntre(Pendulo[i],Pendulo[j], K);
  //Calcular las fuerzas entre todas las parejas de Pendulos

  for(i=0;i<N-1;i++)
    for(j=i+1;j<N;j++)
      CalculeTorqueEntre(Pendulo[i],Pendulo[j], K);
}
void Colisionador::CalculeTorqueEntre(Cuerpo & pendulos1, Cuerpo & pendulos2, double K){
    
    //distancia relativa entre los pendulos
    double d = sqrt(pow(pendulos2.GetX() - pendulos1.GetX(),2) + pow(pendulos2.GetY() - pendulos1.GetY(),2));

    //distancia de interpentracion
    double s = pendulos1.R + pendulos2.R - d;
    

    if(s>0){
      double F = K*pow(s,1.5);
      double tau1 = -1*(F + pendulos1.m*g*sin(pendulos1.GetTheta()))*pendulos2.L;
      double tau2 = (F - pendulos1.m*g*sin(pendulos1.GetTheta()))*pendulos2.L;
      pendulos1.SumeTorque(tau1);
      pendulos2.SumeTorque(tau2);
      
    }
}

//----------- Funciones Globales -----------
//---Funciones de Animacion---
void InicieAnimacion(double K){

  ostringstream oss;
  oss << std::scientific << std::setprecision(1) << static_cast<double>(K);
  
  cout<<"set terminal gif animate delay 10"<<endl; 
  cout<<"set output 'Pendulos_K="<<oss.str()<<".gif'"<<endl;
  cout<<"unset key"<<endl;
  cout<<"set xrange[-20:"<<Lx + 20<<"]"<<endl;
  cout<<"set yrange[-20:"<<Ly + 20<<"]"<<endl;
  cout<<"set size ratio -1"<<endl;
  cout<<"set parametric"<<endl;
  cout<<"set trange [0:7]"<<endl;
  cout<<"set isosamples 12"<<endl;  
}

void InicieCuadro(double t){
  cout << "set label \'t=" << t << "s \' at graph 0.5,0.9 center" << endl;
  cout<<"plot 0,0 ";
}

void TermineCuadro(void){
    cout<<endl;
    cout<<"unset label"<<endl;
}

void Datos(Cuerpo & pendulo, double K){ 

  ostringstream oss;
  oss << std::scientific << std::setprecision(1) << static_cast<double>(K);
  string filename = "PenduloXvsY_K=" + oss.str()  + ".txt";

  ofstream archivo(filename, ios::app); // Open the file in append mode
  archivo << pendulo.GetX() << " " << pendulo.GetY() << endl; // Write the value of tau to the file
  archivo.close(); // Close the file
}

void graficar(double K){

  ostringstream oss;
  oss << std::scientific << std::setprecision(1) << static_cast<double>(K);

  ofstream gp("graph.gp", ios::out);
  if (!gp) {
    cout << "Error al abrir el archivo" << endl;
    return;
  }
  gp << "n=" << N << endl;
  gp << "set terminal png size 800,600" << endl;
  gp << "set output 'Pendulos_K="<<oss.str()<<".png'" << endl;
  gp << "set title 'Trayectoria de los péndulos'" << endl;
  gp << "set xlabel 'Posición X'" << endl;
  gp << "set ylabel 'Posición Y'" << endl;
  gp << "plot for [i=0:n-1] 'PenduloXvsY_K="<<oss.str()<<".txt' every n::i using 1:2 with linespoints pt 7 ps 1 title sprintf('Péndulo %d', i+1)" << endl;
  gp << "set output" << endl;
  gp.close();
}

//-----------------Funciones numeral d -----------------------
void DatosTorqueMax(double tMax, double TauMax, double K, ofstream & archivo){
   // Open the file in append mode
  archivo << tMax << " " << TauMax << endl; // Write the data to the file
}

void TorqueMax(Cuerpo & pendulo, double t, double & tMax, double & TauMax){
  double Tau = pendulo.GetTau();
  if(Tau > TauMax){
    TauMax = Tau;
    tMax = t;
  }
  
}


//------------------ Funciones rendimiento ------------------
void time(double & wsum , double & wsum2 , double & csum , double & csum2,
          double & wtime , double & ctime )
{
    
    wsum  += wtime;
    wsum2 += wtime*wtime;
    csum  += ctime;
    csum2 += ctime*ctime;
    
    
}

void stats(double & wsum , double & wsum2 , double & csum , double & csum2,
          double & wtime , double & ctime, double reps,
          double & mean_wtime, double & sigma_wtime,
          double & mean_ctime, double & sigma_ctime, double K)
{
  mean_wtime = wsum/reps;
  sigma_wtime = std::sqrt(reps*(wsum2/reps - mean_wtime*mean_wtime)/(reps-1));
  mean_ctime = csum/reps;
  sigma_ctime = std::sqrt(reps*(csum2/reps - mean_ctime*mean_ctime)/(reps-1));


  string filename = "Benchmark_CunaNewton.txt";
  ofstream archivo(filename, ios::app); // Open the file in append mode
  archivo<<"\n- Simulación con K = "<<K<<endl;
  archivo<<"\nmean_wtime = "<<mean_wtime<<"s  sigma_wtime = "<<sigma_wtime<<"s"<<endl;
  archivo<<"mean_ctime = "<<mean_ctime<<"s sigma_ctime = "<<sigma_ctime<<"s"<<endl;

  archivo.close();
}

 
  
  
int main(int argc, char *argv[]){
  
  float K = atof(argv[1])*1e9;
  clog<<"\n\n\nK = "<<K<<"\n\n\n";

  Cuerpo pendulos[N];
  Colisionador Newton;
  
  //Archivos para guardar los datos
  ostringstream ossk;
  ossk << scientific << setprecision(1) << static_cast<double>(K);
 
  ofstream archivoXvsY; // Open the file in append mode
  ofstream archivotMaxTauMax;
  ofstream archivoTauK;

  

    archivoXvsY.open("PenduloXvsY_K=" + ossk.str() + ".txt");
    archivotMaxTauMax.open("Punto(tMax,TauMax)_K=" + ossk.str() + ".txt");
    archivoTauK.open("CunaNewtonTau_K=" + ossk.str() + ".txt");
      
    //Variables para el algoritmo
    double m0=100, R0=1.5, L0=12;
    double T=2*M_PI*sqrt(L0/g);
    double t,tstart = 0.174,tmax=0.184,dt=1e-5;
    //double t,tdibujo,dt=1e-5,tmax=2*T_total ,tcuadro=tmax/Ncuadros; 
    int i;

    double tMax = 0, TauMax = 0;

    
    //Variables para medir el rendimiento
    double mean_wtime, sigma_wtime;
    double mean_ctime, sigma_ctime;
    double wsum = 0, wsum2 = 0, csum = 0, csum2 = 0;
    double wtime, ctime;
    double reps = tmax/dt;
    auto start = std::chrono::system_clock::now(); // measures wall time
    std::clock_t c1 = std::clock();

      

  // InicieAnimacion(K);
  // graficar(K);
  
  //---------------(Theta0,Omega0,m0,R0,L0,x00)
  pendulos[0].Inicie(-M_PI/12,0,m0,R0,L0,R0);
	for(i=1; i <N; i++)
			pendulos[i].Inicie(0,0,m0,R0,L0,(2*i+1)*R0);
  

  
 
  for(t=0; t<tmax; t+=dt){

    // if(tdibujo>=tcuadro){
      
    //   InicieCuadro(t);
    //   for(i=0;i<N;i++) {
    //     pendulos[i].Dibujese();
    //     Datos(pendulos[i], K); 
    //     }
    //   TermineCuadro();
      
    //   tdibujo=0;
    // }

    if(t>tstart) { 
            
           TorqueMax(pendulos[1], t, tMax, TauMax);
           archivoTauK<<t<<" "<<pendulos[1].GetTau() <<"\n";
        }
    


    // archivoTauK<<t<<" "<<pendulos[1].GetTau() <<"\n";
    for(i=0;i<N;i++) pendulos[i].Mueva_Theta(dt,xi);    
    Newton.CalculeTodosLosTorques(pendulos,K); 
    for(i=0;i<N;i++) pendulos[i].Mueva_Omega(dt,Um2lambdau2);

    for(i=0;i<N;i++) pendulos[i].Mueva_Theta(dt,chi);
    Newton.CalculeTodosLosTorques(pendulos,K); 
    for(i=0;i<N;i++) pendulos[i].Mueva_Omega(dt,lambda);
    
    for(i=0;i<N;i++) pendulos[i].Mueva_Theta(dt,Um2chiplusxi);
    Newton.CalculeTodosLosTorques(pendulos,K); 
    for(i=0;i<N;i++)pendulos[i].Mueva_Omega(dt,lambda);

    for(i=0;i<N;i++) pendulos[i].Mueva_Theta(dt,chi);
    Newton.CalculeTodosLosTorques(pendulos,K); 
    for(i=0;i<N;i++)pendulos[i].Mueva_Omega(dt,Um2lambdau2);

    for(i=0;i<N;i++) pendulos[i].Mueva_Theta(dt,xi);
    

      // DatosTorque(pendulos[1],t,K,TauPrevio,cambioDeSigno,TauActual,tMax,TauMax,archivoTauK);
      // DatosXyY(pendulos[1], K, archivoXvsY);
  
      clog<<"\nPorcentaje de avance: "<<(t/tmax)*100<<"%"<<endl;

      auto end = std::chrono::system_clock::now(); // wall time
      std::clock_t c2 = std::clock(); // cpu time

      std::chrono::duration<double> elapsed_seconds = end-start;
      
      ctime = 1.0*(c2-c1)/CLOCKS_PER_SEC;
      wtime = elapsed_seconds.count();

      time(wsum, wsum2, csum, csum2, wtime, ctime);

    }

    DatosTorqueMax(tMax, TauMax, K, archivotMaxTauMax);
    stats(wsum, wsum2, csum, csum2, wtime, ctime, reps, mean_wtime, sigma_wtime, mean_ctime, sigma_ctime, K);
    
    //Cierre de archivos
    archivoXvsY.close();
    archivotMaxTauMax.close();
    archivoTauK.close();

    
  
  
  return 0;
}
